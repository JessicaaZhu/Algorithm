Readme File
Open terminal 
Enter dir
Gcc lab1.c
./a.out
