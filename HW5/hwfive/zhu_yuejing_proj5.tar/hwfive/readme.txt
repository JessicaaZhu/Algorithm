Readme File

1.Open terminal 
2.Enter dir

3.make knapsack
./knapsack


